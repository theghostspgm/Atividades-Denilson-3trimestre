
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações Pessoais</title>
</head>
<body>

    <h1>Informações Pessoais</h1>

    <form action="" method="post">

        Digite o nome:
        <input type="text" name="nome">
        <br><br>

        Digite a altura:
        <input type="number" name="altura" step="0.01">
        <br><br>

        Digite o sexo (m/f):
        <input type="text" name="sexo">
        <br><br>

        <input type="submit" value="Calcular">

    </form>

    <?php

    if ($_POST) {

        $nome = $_POST["nome"];
        $altura = $_POST["altura"];
        $sexo = $_POST["sexo"];

        if ($sexo == "m") {

            $peso = (72.7 * $altura) - 58;

            echo "Nome: $nome <br>";
            echo "Sexo: Masculino <br>";
            echo "Peso ideal: $peso kg";

        } else {

            if ($sexo == "f") {

                $peso = (62.1 * $altura) - 44.7;

                echo "Nome: $nome <br>";
                echo "Sexo: Feminino <br>";
                echo "Peso ideal: $peso kg";

            } else {

                echo "Sexo não informado";

            }
        }
    }

    ?>

</body>
</html>




