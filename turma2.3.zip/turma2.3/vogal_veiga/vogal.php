
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogal</title>
</head>
<body>
<form action="" method="post">
    <h1>Vogal</h1>
    Digite uma letra:
    <input type="text" name="letra" required>
    <br><br>
    <input type="submit" value="Enviar">
</form>

<?php
    $letra = $_POST["letra"];
    if ($letra == "a") {
        echo "Digitada a letra A.";
    } else {
        echo "Não foi digitada a letra A.";
    }
?>
</body>
</html>
