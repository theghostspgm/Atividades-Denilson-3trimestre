
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detran</title>
</head>
<body>

<form action="" method="post">
    <h1>Taxa de Transferência</h1>

    Digite o ano do veículo:
    <input type="number" name="ano" required>

    <br><br>

    Digite o valor do veículo:
    <input type="number" name="valor" step="0.01" required>

    <br><br>

    <input type="submit" value="Calcular">
</form>
<br><br>

<?php

        $ano = $_POST["ano"];
        $valor = $_POST["valor"];

        if ($ano < 2015) {
            $taxa = $valor * 0.01;
        } else {
            $taxa = $valor * 0.015;
        }

        echo "A taxa a ser paga é: R$ " . number_format($taxa, 2, ",", ".");   

?>

</body>
</html>
